import torch
from PIL import Image

ROOT_DIR_CITYSCAPES = '../datasets/humanparsingV/SegmentationClassAug/997_12.png'
ROOT_DIR_CITYSCAPES2 = '../saved_images/997_12.png'

if torch.cuda.is_available():
    DEVICE = 'cuda:0'
    print('Running on the GPU')
else:
    DEVICE = "cpu"
    print('Running on the CPU')


im = Image.open(ROOT_DIR_CITYSCAPES2, 'r')
pix_val = list(im.getdata())
print(pix_val)