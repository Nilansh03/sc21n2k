import torch
from torch.utils.data import DataLoader
from torchvision import datasets, utils, transforms
from datasets import CityscapesDataset
from PIL import Image
from tqdm import tqdm
import numpy as np


# folder='./model'
# image_name='eval'

def save_as_images(tensor_pred, folder, image_name):
    tensor_pred = transforms.ToPILImage()(tensor_pred.byte())
    image_name=image_name.replace('.jpg', '.png')
    print(image_name)
    # print(folder)

    filename = f"{folder}\{image_name}"
    print(filename)

    tensor_pred.save(filename)

def get_cityscapes_data(
    relabelled,
    root_dir='datasets/cityscapes',
    target_type="semantic",
    transforms=None,
    batch_size=1,
    eval=False,
    shuffle=True,
    pin_memory=True,

):
    data = CityscapesDataset(
         target_type=target_type, transform=transforms, root_dir=root_dir, eval=eval)

    data_loaded = torch.utils.data.DataLoader(
        data, batch_size=batch_size, shuffle=shuffle, pin_memory=pin_memory)

    return data_loaded

# Functions to save predictions as images 

        


        

    